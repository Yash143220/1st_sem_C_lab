for (j = i; j < n; j++)
        // {
        //     printf(" ");
        // }