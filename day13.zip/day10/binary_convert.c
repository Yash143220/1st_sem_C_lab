// WAP to  find binary equvalant of a decimal no.
#include <stdio.h>
void main()
{

   int n, i, rem;
   printf("Enter the number:");
   scanf("%d", &n);
   int a[n];

   for(i=0;n>0;i++)
   {
      rem = n % 2;
      n /= 2;
      a[i] = rem;
   }
   printf("Binary code is \t");
   for (i--; i >= 0; i--)
   {
      printf("%d", a[i]);
   }
}