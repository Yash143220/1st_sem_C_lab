#include <stdio.h>

void main()
{

    char c[5] = {'k', 'i', 'i', 't'};
    int i;

    for (i = 0; i < 7; i++)
    {
        printf("%c\n", c[i]);
    }
}