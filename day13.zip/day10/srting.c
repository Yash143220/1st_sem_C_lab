/*
What is a string?

string is a compination of character or characters 
                or 
string is a array of characters
*/

#include<stdio.h>

void main(){
    int i;
    char c[50] = "KIIT UNIVERSITY";

    // for ( i = 0; i < 50; i++)
    // {
    //     printf("%c", c[i]);
    // }

    printf("%s",c); //%s is for string 
    
}