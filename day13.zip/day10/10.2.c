/*
WAP to add a cancadinate two string & print it 
*/