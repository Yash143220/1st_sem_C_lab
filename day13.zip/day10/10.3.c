/*
WAP to compare 2 string
*/