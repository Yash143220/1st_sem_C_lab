// WAP to find sum of digit of a number (int) using fucntion

#include <stdio.h>

int digit();

void main()
{
    printf("The sum of digits of a number is %d\n", digit());
}

int digit()
{
    int num, rem, sum = 0;
    printf("Enter the number:");
    scanf("%d", &num);

    while (num != 0)
    {
        rem = num % 10;
        num /= 10;
        sum += rem;
    }

    return (sum);
}
